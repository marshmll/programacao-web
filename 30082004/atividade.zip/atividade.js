let form = document.getElementById("form")

function submitForm() {
    form.submit();
}

function resetForm() {
    form.reset();
}